/**
 * Created by samuel on 17/06/14.
 */
var _importScripts = new ImportScripts();

_importScripts.setScript(
    "js/libs/jquery-1.10.1.js",
    "js/libs/i18next-1.7.3.js",
    "js/libs/bootstrap.js");

_importScripts.setReq("js/index");
